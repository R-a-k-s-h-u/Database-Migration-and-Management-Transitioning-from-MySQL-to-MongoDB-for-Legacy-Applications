require("dotenv").config();
const mysql = require("mysql2/promise");
const mongoose = require("mongoose");

// MySQL Connection
const mysqlPool = mysql.createPool({
    host: process.env.MYSQL_HOST,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DATABASE,
});

// MongoDB Connection
mongoose.connect("https://downloads.mongodb.com/compass/mongodb-compass-1.45.3-darwin-arm64.dmg", { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;
db.on("error", console.error.bind(console, "MongoDB connection error:"));
db.once("open", () => console.log("Connected to MongoDB"));

// Define MongoDB Schemas
const BranchSchema = new mongoose.Schema({
    branch_id: String,
    student_id: String,
    branch_address: String,
    contact_no: String,
});
const StudentSchema = new mongoose.Schema({
    stud_id: String,
    stud_name: String,
    branch_id: String,
    sem: Number,
    contact_no: String,
});
const BookSchema = new mongoose.Schema({
    book_id: String,
    book_title: String,
    rental_price: Number,
    status: String,
    author: String,
    publisher: String,
});
const MemberSchema = new mongoose.Schema({
    member_id: String,
    member_name: String,
    member_address: String,
    reg_date: Date,
});
const IssuedStatusSchema = new mongoose.Schema({
    issued_id: String,
    issued_member_id: String,
    issued_book_name: String,
    issued_date: Date,
    issued_book_id: String,
});
const ReturnStatusSchema = new mongoose.Schema({
    return_id: String,
    issued_id: String,
    return_book_name: String,
    return_date: Date,
    return_book_id: String,
});

// MongoDB Models
const Branch = mongoose.model("Branch", BranchSchema);
const Student = mongoose.model("Student", StudentSchema);
const Book = mongoose.model("Book", BookSchema);
const Member = mongoose.model("Member", MemberSchema);
const IssuedStatus = mongoose.model("IssuedStatus", IssuedStatusSchema);
const ReturnStatus = mongoose.model("ReturnStatus", ReturnStatusSchema);

// Migration Function
async function migrateTable(tableName, Model) {
    try {
        console.log(`Migrating ${tableName}...`);
        const [rows] = await mysqlPool.query(`SELECT * FROM ${tableName}`);
        await Model.insertMany(rows);
        console.log(` ${tableName} migrated successfully!`);
    } catch (err) {
        console.error(`Error migrating ${tableName}:`, err);
    }
}

// Run Migration
async function migrateData() {
    await migrateTable("branch", Branch);
    await migrateTable("students", Student);
    await migrateTable("books", Book);
    await migrateTable("members", Member);
    await migrateTable("issued_status", IssuedStatus);
    await migrateTable("return_status", ReturnStatus);

    console.log(" Migration completed!");
    process.exit();
}

migrateData();
