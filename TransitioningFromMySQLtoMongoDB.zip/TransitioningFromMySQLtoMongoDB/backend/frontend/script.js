document.addEventListener("DOMContentLoaded", function () {
    fetchBooks();
    fetchMembers();
    fetchIssuedBooks();
    fetchReturnStatus();
});

function fetchBooks() {
    fetch("http://localhost:5000/api/books")
        .then(response => response.json())
        .then(data => {
            let bookList = document.getElementById("books");
            bookList.innerHTML = "";
            data.forEach(book => {
                let row = `<tr>
                    <td>${book.book_id}</td>
                    <td>${book.book_title}</td>
                    <td>${book.rental_price}</td>
                    <td>${book.status}</td>
                    <td>${book.author}</td>
                    <td>${book.publisher}</td>
                </tr>`;
                bookList.innerHTML += row;
            });
        })
        .catch(error => console.error("Error fetching books:", error));
}

function fetchMembers() {
    fetch("http://localhost:5000/api/members")
        .then(response => response.json())
        .then(data => {
            let memberList = document.getElementById("members");
            memberList.innerHTML = "";
            data.forEach(member => {
                let row = `<tr>
                    <td>${member.member_id}</td>
                    <td>${member.member_name}</td>
                    <td>${member.member_address}</td>
                    <td>${member.reg_date}</td>
                </tr>`;
                memberList.innerHTML += row;
            });
        })
        .catch(error => console.error("Error fetching members:", error));
}

function fetchIssuedBooks() {
    fetch("http://localhost:5000/api/issued-books")
        .then(response => response.json())
        .then(data => {
            let issuedList = document.getElementById("issued-books");
            issuedList.innerHTML = "";
            data.forEach(issue => {
                let row = `<tr>
                    <td>${issue.issued_id}</td>
                    <td>${issue.issued_member_id}</td>
                    <td>${issue.issued_book_name}</td>
                    <td>${issue.issued_date}</td>
                    <td>${issue.issued_book_id}</td>
                </tr>`;
                issuedList.innerHTML += row;
            });
        })
        .catch(error => console.error("Error fetching issued books:", error));
}

function fetchReturnStatus() {
    fetch("http://localhost:5000/api/return-status")
        .then(response => response.json())
        .then(data => {
            let returnList = document.getElementById("return-status");
            returnList.innerHTML = "";
            data.forEach(returnItem => {
                let row = `<tr>
                    <td>${returnItem.return_id}</td>
                    <td>${returnItem.issued_id}</td>
                    <td>${returnItem.return_book_name}</td>
                    <td>${returnItem.return_date}</td>
                    <td>${returnItem.return_book_id}</td>
                </tr>`;
                returnList.innerHTML += row;
            });
        })
        .catch(error => console.error("Error fetching return status:", error));
}
