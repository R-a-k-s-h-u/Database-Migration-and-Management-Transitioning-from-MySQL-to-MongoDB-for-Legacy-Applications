const express = require("express");
const mysql = require("mysql");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// MySQL Connection
const mysqlDB = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Rakshu@123",
    database: "libby_management"
});

mysqlDB.connect(err => {
    if (err) console.error("MySQL Connection Failed:", err);
    else console.log("Connected to MySQL");
});

// MongoDB Connection
mongoose.connect("mongodb://127.0.0.1:27017/library_management", {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const StudentSchema = new mongoose.Schema({
    stud_id: String,
    stud_name: String,
    branch_id: String,
    sem: Number,
    contact_no: String
});

const Student = mongoose.model("Student", StudentSchema);

// API to Fetch MySQL Data
app.get("/api/students", (req, res) => {
    mysqlDB.query("SELECT * FROM students", (err, result) => {
        if (err) res.status(500).send(err);
        else res.json(result);
    });
});

// API to Migrate Data to MongoDB
app.get("/api/migrate", async (req, res) => {
    mysqlDB.query("SELECT * FROM students", async (err, results) => {
        if (err) {
            res.status(500).json({ message: "MySQL Query Failed" });
            return;
        }
        try {
            await Student.insertMany(results);
            res.json({ message: "Data Migrated Successfully!" });
        } catch (error) {
            res.status(500).json({ message: "MongoDB Insertion Failed" });
        }
    });
});

// Start Server
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});
