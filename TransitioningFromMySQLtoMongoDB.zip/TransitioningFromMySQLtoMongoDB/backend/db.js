const { MongoClient } = require('mongodb');
const mongoUri = 'mongodb://localhost:27017';
const mongoDbName = 'library_management';

const client = new MongoClient(mongoUri);
async function connectDB() {
    await client.connect();
    console.log('Connected to MongoDB');
    return client.db(mongoDbName);
}
module.exports = connectDB;